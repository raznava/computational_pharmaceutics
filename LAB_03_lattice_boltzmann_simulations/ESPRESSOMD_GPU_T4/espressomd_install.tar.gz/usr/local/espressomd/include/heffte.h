/*
    -- heFFTe --
       Univ. of Tennessee, Knoxville
       @date
*/

#ifndef HEFFTE_H
#define HEFFTE_H

#ifdef __cplusplus

#include "heffte_fft3d_r2c.h"

#else

#include "heffte_c.h"

#endif

#endif     /* HEFFTE_H */
